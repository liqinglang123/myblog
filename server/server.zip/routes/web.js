const express = require('express')

const web = express.Router()

const Blogger = require('../model/blogger')
const Article = require('../model/article')
const Comment = require('../model/comment')
const Diary = require('../model/diary')
const Album = require('../model/album')
const Message = require('../model/message')
const Tag = require('../model/tag')
const Category = require('../model/category')

// 获取个人信息
web.get('/blogger', async (req, res) => {
    Blogger.findOne((err, data) => {
        if (!err) {
            res.send(data)
        }
    })
})

// 查询所有文章
web.get('/article-all', async (req, res) => {
    // console.log(req.query)
    let { pageindex, pagesize } = req.query

    let result = await Article.find()
    let count = result.length

    let data = await Article.find().limit(pagesize - 0).skip((pageindex - 0 - 1) * (pagesize - 0)).populate('tags').populate('category').populate('comments').sort({ readcount: -1 }).exec()

    res.status(200).send({ count, data })

})

// 获取一篇文章
web.get('/article-one', async (req, res) => {
    let _id = req.query.id
    // 根据id查询文章
    Article.findOne({ _id }).populate('tags').populate('category').populate('comments').exec((err, result) => {
        res.send(result)
    })
})

// 文章阅读量增加
web.get('/add-count', async (req, res) => {
    let { id, readcount } = req.query
    Article.findByIdAndUpdate({ _id: id }, { readcount: readcount }, err => {
        res.send()
    })
})

// 评论
web.get('/post-comment', async (req, res) => {
    // 获取文章id
    let { id } = req.query
    // console.log()
    Comment.create(req.query)
        .then(data => {
            // let id = data._id
            // res.send(data)
            Article.update({ _id: id }, { $push: { comments: data._id } }, err => {
                if (!err) {
                    res.send({ success: true, msg: '评论发表成功' })
                } else {
                    res.send({ success: false, msg: '评论发表失败' })
                }
            })
        })
        .catch(err => {
            console.log(err)
            res.send({ success: false, msg: '评论失败' })
        })
})

// 获取所有日记
web.get('/diary-all', (req, res) => {
    Diary.find().sort({ time: -1 }).exec((err, data) => {
        // console.log(err)
        if (!err) {
            res.send(data)
        }
    })
})

// 获取所有相册
web.get('/albums', (req, res) => {
    Album.find((err, data) => {
        if (!err) {
            res.send(data)
        }
    })
})

// 查询一个相册
web.get('/album-one', (req, res) => {
    let { id } = req.query
    // 查找并返回数据
    Album.findOne({ _id: id }, (err, data) => {
        if (!err) {
            res.send(data)
        } else {
            console.log(err)
            res.send()
        }
    })
})

// 添加留言
web.get('/add-message', (req, res) => {
    Message.create(req.query, error => {
        if (!error) {
            res.send({ success: true, msg: '评论发表成功' })
        } else {
            console.log(error)
            res.send({ success: false, msg: '评论发表失败' })
        }
    })
})

// 查询所有留言
web.get('/message-all', async (req, res) => {
    let messages = await Message.find()
    let count = messages.length
    // 先查找所有评论
    let data = await Message.find({ parentId: { $eq: '' } }).sort({ updatedAt: -1 })
    // 为所有评论查找回复
    data.forEach(async (item, index) => {
        let result = await Message.find({ parentId: { $eq: item._id } }).sort({ updatedAt: 1 })
        item.replys = result
        if (index === data.length - 1) {
            res.send({ data, count })
        }
    })
})

// 查询所有文章用于首页
web.get('/articles', async (req, res) => {
    let result = await Article.find({}, { body: 0 }).populate('tags').populate('category').populate('comments').sort({ readcount: -1 }).exec()
    res.status(200).send(result)
})

// 精确查询根据标题和正文的内容
web.get('/search', async (req, res) => {
    let { str } = req.query
    let result = await Article.find({ $or: [{ "title": { $regex: str, $options: "i" } }, { "body": { $regex: str, $options: "i" } }] }, { body: 0 })
    res.send(result)
})

// 查询所有热门标签
web.get('/hot-tag', async (req, res) => {
    Tag.find((err, data) => {
        if (!err) {
            res.send(data)
        } else {
            console.log(err)
        }
    })
})

//根据标签id查找文章
web.get('/find-tag', async (req, res) => {
    let { id } = req.query
    let result = await Article.find({ tags: { $in: id } }, { body: 0 })
    res.send(result)
})


// 获取所有标签
web.get('/categories', async (req, res) => {
    let data = await Category.find()
    res.send(data)
})

// 根据分类查找文章
web.get('/find-category', async (req, res) => {
    let { id } = req.query
    let data = await Article.find({ category: { $eq: id } }, { body: 0 })
    res.send(data)
})



module.exports = web