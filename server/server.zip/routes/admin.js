const express = require('express')
const { encrypt } = require('../utils/plugin')

const qs = require('qs')

// 引入token的相关方法
const { createToken, varifyToken, errorToken } = require('../utils/token')

const { User } = require('../model/user')
const Tag = require('../model/tag')
const Category = require('../model/category')
const Comment = require('../model/comment')
const Article = require('../model/article')
const Blogger = require('../model/blogger')
const Diary = require('../model/diary')
const Album = require('../model/album')

const admin = express.Router()

const md5 = require('md5')

// 验证token
admin.use(varifyToken())

async function createUser() {
    const user = await Blogger.create({
        name: 'lisi',
        sex: '男',
        phone: '18373298616',
        email: '3159956778@qq.com',
        nativePlace: '湖南扣滴',
        // 政治面貌
        politicalOutlook: '娄底',
        school: '湖南科技大学',
        birthday : '2001-01-12',
        // 学历
        degree: '本科',
        occupation: 'web前端',
        description: '我叫李晴朗',
        hobbies : '唱歌跳舞',
        sayings1 : '勇往直前 向前冲',
        sayings2 : '冲冲冲'
    })
}

// createUser();

// 实现登录功能
admin.post('/login', async (req, res) => {
    // 获取参数
    let { username, password } = req.body
    // 对密码进行加密
    password = encrypt(password)
    // 查询用户是否存在
    let user = await User.findOne({ username, password })
    if (user) {
        let token = createToken(user.username, 60 * 60 * 24)
        res.status(200).send({ success: true, msg: '用户名和密码正确', token })
    } else {
        res.status(200).send({ success: false, msg: '用户名或密码错误' })
    }
})

// 查询所有分类
admin.get('/category-all', async (req, res) => {
    let data = await Category.find()
    res.send(data)
})

// 查询某个分类
admin.get('/category-one', async (req, res) => {
    let { _id } = req.query
    let data = await Category.find({ _id })
    res.send(data[0])
})

// 查询所有标签
admin.get('/tag-all', async (req, res) => {
    let data = await Tag.find()
    res.send(data)
})

// 查询某个标签
admin.get('/tag-one', async (req, res) => {
    let { _id } = req.query
    // 查找标签
    let data = await Tag.find({ _id })
    res.send(data[0])
})

// 更新某个分类
admin.post('/category-update', async (req, res) => {
    let { _id, name } = req.body

    // 判断是否有文章使用该分类
    let articles = await Article.find({ category: { $eq: _id } })

    // 如果有文章使用该分类
    if (articles.length) {
        res.send({ success: false, msg: '修改失败 , 该分类正在使用中...' })
    } else {
        let data = await Category.find({ name })

        // 如果分类已经存在
        if (data.length) {
            res.send({ success: false, msg: '分类重复! 修改失败' })
        } else {
            await Category.findByIdAndUpdate({ _id }, { name }, err => {
                if (!err) {
                    res.send({ success: true, msg: '修改成功' })
                } else {
                    res.send({ success: false, msg: '修改失败' })
                }
            })
        }
    }

})

// 删除某个分类
admin.post('/category-delete', async (req, res) => {
    let { _id, name } = req.body

    // 判断是否有文章使用该分类
    let articles = await Article.find({ category: { $eq: _id } })

    // 如果有文章使用该分类
    if (articles.length) {
        res.send({ success: false, msg: '删除失败 , 已有文章使用该分类' })
    } else {
        await Category.findByIdAndDelete({ _id, name }, err => {
            if (!err) {
                res.send({ success: true, msg: '分类删除成功' })
            } else {
                res.send({ success: false, msg: '分类删除失败' })
            }
        })
    }
})

// 更新某个标签
admin.post('/tag-update', async (req, res) => {
    let { _id, name } = req.body

    // 判断是否有文章使用该标签
    let articles = await Article.find({ tags: { $in: [_id] } })

    // 如果有文章使用该标签
    if (articles.length) {
        res.send({ success: false, msg: '修改失败 , 标签正在使用中...' })
    } else {
        let data = await Tag.find({ name })

        // 判断标签是否已经存在
        if (data.length) {
            res.send({ success: false, msg: '标签重复!修改失败' })
        } else {
            await Tag.findByIdAndUpdate({ _id }, { name }, err => {
                if (!err) {
                    res.send({ success: true, msg: '标签修改成功' })
                } else {
                    res.send({ success: false, msg: '标签修改失败' })
                }
            })
        }
    }
})

// 删除某个标签
admin.post('/tag-delete', async (req, res) => {
    let { _id, name } = req.body

    // 判断是否有文章使用该标签
    let articles = await Article.find({ tags: { $in: [_id] } })

    // 如果有文章使用该标签
    if (articles.length) {
        res.send({ success: false, msg: '删除失败 , 已有文章使用该标签' })
    } else {
        Tag.findByIdAndDelete({ _id }, err => {
            if (!err) {
                res.send({ success: true, msg: '标签删除成功' })
            } else {
                res.send({ success: false, msg: '标签删除失败' })
            }
        })
    }

    // Comment.findOne({content: 'walala'}).then(function(comment) {
    //     return User.update({comments: {$in: [comment._id]}}, {$pull: {'comments': comment._id}}, {multi: true}).exec();
    //   }).then(function(res) {
    //     console.log(res);
    //   });
    //  {multi: true}  代表查询所有
})

// 添加文章分类
admin.post('/category-add', async (req, res) => {
    let { name } = req.body
    // 查询分类是否存在
    Category.find({ name }, (err, result) => {
        if (result.length) {
            res.send({ success: false, msg: '该分类已经存在,添加失败' })
        } else {
            Category.create({ name }, err => {
                if (!err) {
                    res.send({ success: true, msg: '分类添加成功' })
                } else {
                    res.send({ success: false, msg: '分类添加失败' })
                }
            })
        }
    })
    // 如果存在
    // if (category.length) {
    //     res.send({ success: false, msg: '该分类已经存在,添加失败' })
    // } else {
    //     let data = await Category.create({ name })
    //     // 添加成功
    //     if (data) {
    //         res.send({ success: true, msg: '分类添加成功' })
    //     } else {
    //         res.send({ success: false, msg: '分类添加失败' })
    //     }
    // }
})

// 添加标签
admin.post('/tag-add', async (req, res) => {
    let { name } = req.body
    // 查询该标签是否存在
    Tag.find({ name }, (err, result) => {
        if (result.length) {
            res.send({ success: false, msg: '该标签已经存在,添加失败' })
        } else {
            Tag.create({ name }, err => {
                if (!err) {
                    res.send({ success: true, msg: '标签添加成功' })
                } else {
                    res.send({ success: true, msg: '标签添加失败' })
                }
            })
        }
    })
    // 如果存在
    // if (tag.length) {
    //     res.send({ success: false, msg: '该标签已经存在,添加失败' })
    // } else {
    //     let data = await Tag.create({ name })
    //     // 添加成功
    //     if (data) {
    //         res.send({ success: true, msg: '标签添加成功' })
    //     } else {
    //         res.send({ success: true, msg: '标签添加失败' })
    //     }
    // }
})

// 添加文章
admin.post('/article-add', async (req, res) => {
    // res.send(req.body)
    // const { title, category, body, ...list } = req.body
    // const tags = Object.values(list)

    // 获取参数并且格式化
    const data = qs.parse(req.body)

    // 保存文章
    Article.create(data, err => {
        if (!err) {
            res.send({ success: true, msg: '文章添加成功！！' })
        } else {
            res.send({ success: false, msg: '文章添加失败！！' })
        }
    })
})

// 查询所有文章
admin.post('/article-all', async (req, res) => {
    // let tags = []
    // // 获取tags属性
    // Object.keys(req.body).forEach(item => {
    //     if (item.indexOf('tags') !== -1) {
    //         tags.push(req.body[item])
    //     }
    // })

    // 格式化参数并且获取tags
    const tags = qs.parse(req.body).tags || []

    // 过滤数据
    let filters = function (arr) {
        // let { pageIndex, pageSize } = req.body
        // let skipCount = (pageIndex - 1) * pageSize
        let result = []
        arr.forEach(item => {
            if (tags.every(val => item.tags.includes(val))) {
                result.push(item)
            }
        })
        // let count = result.length
        // // 截取数据
        // let data = result.splice(skipCount, pageSize)
        // // console.log(data)

        // return res.send({ data, count })
        res.send(result)
    }

    if (req.body.category === "") {
        Article.find({}, { comments: 0, body: 0 }).sort({ updatedAt: -1 }).populate('category').exec((err, data) => {
            // res.send(filters(data))
            filters(data)
        })
    } else {
        Article.find({ category: { $eq: req.body.category } }, { comments: 0, body: 0 }).sort({ updatedAt: -1 }).populate('category').exec((err, data) => {
            filters(data)
        })
    }
})

// 查询一篇文章
admin.get('/article-one', async (req, res) => {
    let { _id } = req.query
    Article.findById({ _id }, (err, result) => res.send(result))
})

// 删除文章 
admin.post('/article-delete', async (req, res) => {
    let { _id } = req.body
    Article.deleteOne({ _id }, (err) => {
        if (!err) {
            res.send({ success: true, msg: '文章删除成功' })
        } else {
            res.send({ success: false, msg: '文章删除失败' })
        }
    })
})

// 更新文章
admin.post('/article-update', (req, res) => {
    const { _id } = req.body
    const data = qs.parse(req.body)
    // 没有使用qs时
    // let tags = []

    // // 获取tags属性
    // Object.keys(req.body).forEach(item => {
    //     if (item.indexOf('tags') !== -1) {
    //         tags.push(req.body[item])
    //     }
    // })

    // // 给data添加tags属性
    // Object.defineProperty(data, "tags", { enumerable: true, configurable: true, writable: true, value: tags })

    // 更新文章
    Article.findByIdAndUpdate({ _id }, data, (err) => {
        if (!err) {
            res.send({ success: true, msg: '文章更新成功' })
        } else {
            res.send({ success: false, msg: '文章更新失败' })
        }
    })
})

// 查找博主信息
admin.get('/blogger', async (req, res) => {
    let data = await Blogger.findOne()
    res.send(data)
})

// 更新博主信息
admin.post('/blogger-update', async (req, res) => {
    const { _id } = req.body
    const data = req.body
    data.birthday = new Date(req.body.birthday)
    Blogger.findByIdAndUpdate({ _id }, data, err => {
        if (!err) {
            res.send({ success: true, msg: '博主信息修改成功' })
        } else {
            res.send({ success: false, msg: '博主信息修改失败' })
        }
    })
})

// 查找所有用户
admin.get('/user-all', async (req, res) => {
    User.find({}, { password: 0 }, (err, data) => {
        res.send(data)
    })
})

// 查询所有日记
admin.get('/diary-all', async (req, res) => {
    Diary.find().sort({ time: -1 }).exec((err, data) => {
        if (!err) {
            res.send(data)
        } else {
            console.log(data)
        }
    })
})

// 查询一篇日记
admin.get('/diary-one', (req, res) => {
    let { id } = req.query
    Diary.findOne({ _id: id }, (err, data) => {
        res.send(data)
    })
})

// 添加日记
admin.post('/diary-add', async (req, res) => {
    const data = qs.parse(req.body)
    Diary.create(data, err => {
        if (!err) {
            res.send({ success: true, msg: '日记添加成功' })
        } else {
            res.send({ success: false, msg: '日记添加失败' })
        }
    })
})

// 更新日记
admin.post('/diary-update', async (req, res) => {
    // console.log(req.body)
    let { _id } = req.body
    Diary.findByIdAndUpdate({ _id }, req.body, err => {
        if (!err) {
            res.send({ success: true, msg: '日记更新成功' })
        } else {
            res.send({ success: false, msg: '日记更新失败' })
        }
    })
})

// 删除日记
admin.get('/diary-delete', async (req, res) => {
    let { id } = req.query
    Diary.findByIdAndDelete({ _id: id }, err => {
        if (!err) {
            res.send({ success: true, msg: '日记删除成功' })
        } else {
            res.send({ success: false, msg: '日记删除失败' })
        }
    })
})

// 查询所有相册
admin.get('/albums', (req, res) => {
    Album.find((err, data) => {
        if (!err) {
            res.send(data)
        }
    })
})

// 相册
admin.post('/album-add', (req, res) => {
    // console.log(req.body)
    let data = qs.parse(req.body)
    Album.create(data, err => {
        if (err) {
            res.send({ success: false, msg: '相册创建失败' })
        } else {
            res.send({ success: true, msg: '相册创建成功' })
        }
    })
})

// 查询一个相册
admin.get('/album-one', (req, res) => {
    // console.log(req)
    let { id } = req.query
    // 查找并返回数据
    Album.findOne({ _id: id }, (err, data) => {
        if (!err) {
            res.send(data)
        } else {
            console.log(err)
            res.send()
        }
    })
})

// 更新相册
admin.post('/album-update', (req, res) => {
    let data = qs.parse(req.body)
    let id = data.id || data._id
    if (!data.pictures) {
        data.pictures = []
    }
    // 查找并更新相册
    Album.findByIdAndUpdate({ _id: id }, data, err => {
        if (!err) {
            res.send({ success: true, msg: '相册更新成功' })
        } else {
            res.send({ success: false, msg: '相册更新失败' })
        }
    })
})

// 删除相册
admin.get('/album-delete', async (req, res) => {
    // console.log(req.query)
    let { id } = req.query

    // 删除相册
    Album.findByIdAndRemove({ _id: id }, err => {
        if (!err) {
            res.send({ success: true, msg: '相册删除成功' })
        } else {
            res.send({ success: false, msg: '相册删除失败' })
        }
    })
    // console.log('完结')
})
// 处理错误组件
admin.use(errorToken)

module.exports = admin