const express = require('express')
const fs = require('fs')
const path = require('path')

const router = express.Router()

// 上传图片的模板
const multer = require('multer')
const { RSA_NO_PADDING } = require('constants')

const upload = multer({ dest: 'uploads/' })

// 图片上传必须使用post方法
router.post('/img', upload.single('file'), (req, res) => {
    // console.log('请求了')
    fs.readFile(req.file.path, (err, data) => {
        // 读取失败, 没有上传成功
        if (err) {
            res.send({ success: false, msg: '图片上传失败' })
        }
        fs.writeFile(path.join(__dirname, '../static/img', req.file.originalname), data, err => {
            if (err) {
                res.send({ success: false, msg: '图片上传失败' })
            }
            // console.log('用户上传了一张图片')
            res.send({ success: true, filename: req.file.originalname, msg: '图片上传成功' })
        })
    })
})
// router.post('/img', upload.single('test'), (req, res) => {
//     // console.log(req.file);
//     console.log(req)
//     fs.readFile(req.file.path, (err, data) => {
//         console.log(req.file)
//         // 读取失败, 没有上传成功
//         if (err) {
//             res.send({ success: false, msg: '图片上传失败' })
//         }
//         console.log('sssss')
//         fs.writeFile(path.join(__dirname, '../static/img', req.file.originalname), data, err => {
//             if (err) {
//                 res.send({ success: false, msg: '图片上传失败' })
//             }
//             console.log('用户上传了一张图片')
//             res.send({ success: true, filename: req.file.originalname, msg: '图片上传成功' })
//         })
//     })
// })

// 返回base64格式
// router.get('/getImg', (req, res) => {
//     let { filename } = req.query
//     var chunks = []
//     var size = 0
//     const cs = fs.createReadStream(path.resolve(__dirname, '../uploads', filename))
//     cs.on('data', chunk => {
//         // res.write(chunk)
//         chunks.push(chunk)
//         size += chunk.length  //累加缓冲数据的长度
//     })
//     cs.on('end', () => {
//         var data = Buffer.concat(chunks, size)
//         // res.send(data.toString('binary'))

//         // var base64Img = data.toString('base64')
//         // res.send(`data:img/png;base64,${base64Img}`)
//     })
// })

router.get('/getImg', (req, res) => {
    let { filename } = req.query
    let filepath = path.join(__dirname, '../static/img', filename)
    res.set('content-type', 'image/png')
    fs.readFile(filepath, (err, data) => {
        res.send(data)
    })

    // var resData = []
    // let cs = fs.createReadStream(filepath)
    // cs.on("data", chunk => {
    //     resData.push(chunk)
    // })
    // cs.on("end", () => {
    //     var finalData = Buffer.concat(resData)
    //     res.send(finalData)
    // })
    // stream.pipe(res)
    // res.send(stream)
})

module.exports = router


